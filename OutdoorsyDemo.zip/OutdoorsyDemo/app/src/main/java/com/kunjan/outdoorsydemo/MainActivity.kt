package com.kunjan.outdoorsydemo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.kunjan.outdoorsydemo.pojo.Rentals
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers



class MainActivity : AppCompatActivity() {
    var disposable: Disposable? = null
    lateinit var recyclerView:RecyclerView
    private val getApiService by lazy {
        ApiService.create()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        recyclerView = findViewById(R.id.recycler_rental)
        val compositeDisposable = CompositeDisposable()
        val userObservable = getApiService.getAllRentals()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe({ result -> setRecyclerView(result!!) },
                { error -> showError(error) }
            )
        compositeDisposable.add(userObservable)

    }

    private fun setRecyclerView(result: List<Rentals>) {
        val rentalAdapter = RentalAdapter(result)
        Toast.makeText(this,result.toString(),Toast.LENGTH_LONG).show()
        recyclerView.itemAnimator = DefaultItemAnimator()
        val layoutManager = LinearLayoutManager(this)
        layoutManager.orientation = LinearLayoutManager.VERTICAL
        recyclerView.layoutManager = layoutManager
        recyclerView.adapter = rentalAdapter
        recyclerView.addItemDecoration(DividerItemDecoration(this,LinearLayoutManager.VERTICAL))
    }

    private fun showError(message: Any) {
        Toast.makeText(this,message.toString(),Toast.LENGTH_LONG).show()
    }
}