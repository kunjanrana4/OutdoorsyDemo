package com.kunjan.outdoorsydemo

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.kunjan.outdoorsydemo.pojo.Rentals

class RentalAdapter(val rental_list : List<Rentals>) :
    RecyclerView.Adapter<RentalAdapter.ViewHolder>() {
    class ViewHolder(itemView: View):RecyclerView.ViewHolder(itemView) {
        val img:ImageView = itemView.findViewById(R.id.img)
        val name = itemView.findViewById<TextView>(R.id.name)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val context = parent.context
        val inflater = LayoutInflater.from(context)
        val view = inflater.inflate(R.layout.list_item, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return rental_list.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val rental = rental_list[position]
        //Image attribute was asked but its not available in json
        holder.name.text = rental.data[position].attributes.name
    }
}